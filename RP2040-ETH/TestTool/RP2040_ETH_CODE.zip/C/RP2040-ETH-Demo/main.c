﻿#include "CH9120_Test.h"

int main()
{
    Pico_ETH_CH9120_test();
}
